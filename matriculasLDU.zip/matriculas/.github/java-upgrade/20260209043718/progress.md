# Upgrade Progress

  ### ❗ Generate Upgrade Plan
  - [[View Log]](logs\1.generatePlan.log)
  
  <details>
      <summary>[ click to toggle details ]</summary>
  
  #### Errors
  - Failed to get git status for c:\Users\LUIS\Desktop\matriculas: "git" no se reconoce como un comando interno o externo, programa o archivo por lotes ejecutable.
  </details>