package com.denm.matriculas;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MatriculasApplicationTests {

	@Test
	void contextLoads() {
	}

}
